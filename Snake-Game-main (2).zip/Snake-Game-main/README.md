# Snake-Game
First Task Given By SYNC Interns
